-- 岩笋的回归夹具：装进 UE4SS 的 Mods 后启动游戏，日志里应该出现「has enabled.txt, starting mod.」
print("[ProSproutLua] 岩笋探针到了\n")